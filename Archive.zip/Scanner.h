#ifndef SCANNER
#define SCANNER
#include <string>
#include <iostream>
#include "Token.h"
#include "StateMachine.h"
#include <fstream>      // std::ifstream


class ScannerClass{

public:
    ScannerClass(const std::string& input);
    ~ScannerClass();
    TokenClass GetNextToken();
private:
    std::ifstream mFin;

};

#endif //SCANNER