#include "StateMachine.h"
#include <iostream>
#include <iomanip>

StateMachineClass::StateMachineClass(){
    std::cout << "TokenClass was constructed" << std::endl;
    mCurrentState = START_STATE;
    // First, initialize all the mLegalMoves to CANTMOVE_STATE
    // Then, reset the mLegalMoves that are legitimate
    for(int i=0; i<LAST_STATE; i++){
        for(int j=0; j<LAST_CHAR; j++){
            mLegalMoves[i][j] = CANTMOVE_STATE;
        }
    }
    mLegalMoves[START_STATE][DIGIT_CHAR]= INTEGER_STATE; // S -> DIGIT
    mLegalMoves[INTEGER_STATE][DIGIT_CHAR]= INTEGER_STATE;
    mLegalMoves[START_STATE][PLUS_CHAR]= PLUS_STATE;
    mLegalMoves[START_STATE][MINUS_CHAR]= MINUS_STATE;
    mLegalMoves[START_STATE][SEMICOLON_CHAR]= SEMICOLON_STATE;
    mLegalMoves[START_STATE][LESS_CHAR]= LESS_STATE;
    mLegalMoves[LESS_STATE][LESS_CHAR]= INSERTION_STATE;
    mLegalMoves[LESS_STATE][EQUAL_CHAR]= LESSEQUAL_STATE;
    mLegalMoves[START_STATE][GREATER_CHAR]= GREATER_STATE;
    mLegalMoves[GREATER_STATE][EQUAL_CHAR]= GREATEREQUAL_STATE;
    mLegalMoves[START_STATE][EQUAL_CHAR]= EQUAL_STATE;
    mLegalMoves[EQUAL_STATE][EQUAL_CHAR]= COMPARE_STATE;
    mLegalMoves[START_STATE][DIVIDE_CHAR]= DIVIDE_STATE;
    mLegalMoves[DIVIDE_STATE][DIVIDE_CHAR] = LINE_COMMENT_STATE;
    mLegalMoves[LINE_COMMENT_STATE][NEWL_CHAR]= START_STATE;
    mLegalMoves[DIVIDE_STATE][STAR_CHAR]= COMMENT_STATE;
    mLegalMoves[COMMENT_STATE][!STAR_CHAR]= COMMENT_STATE;
    mLegalMoves[COMMENT_STATE][STAR_CHAR]= CLOSING_COMMENT_STATE;
    mLegalMoves[CLOSING_COMMENT_STATE][STAR_CHAR]= CLOSING_COMMENT_STATE;
    mLegalMoves[CLOSING_COMMENT_STATE][!DIVIDE_CHAR&!STAR_CHAR]= COMMENT_STATE;
    mLegalMoves[CLOSING_COMMENT_STATE][DIVIDE_CHAR]= START_STATE;
    mLegalMoves[START_STATE][LPAREN_CHAR]= LPAREN_STATE;
    mLegalMoves[START_STATE][RPAREN_CHAR]= RPAREN_STATE;
    mLegalMoves[START_STATE][LCURLY_CHAR]= LCURLY_STATE;
    mLegalMoves[START_STATE][RCURLY_CHAR]= RCURLY_STATE;
    mLegalMoves[START_STATE][LETTER_CHAR]= IDENTIFIER_STATE;
    mLegalMoves[IDENTIFIER_STATE][LETTER_CHAR]= IDENTIFIER_STATE;
    mLegalMoves[IDENTIFIER_STATE][DIGIT_CHAR]= IDENTIFIER_STATE;
    mLegalMoves[START_STATE][EOF_CHAR]= EOF_STATE;
    mLegalMoves[START_STATE][WHITESPACE_CHAR]= START_STATE;
    mLegalMoves[START_STATE][NOT_CHAR]= NOT_STATE;
    mLegalMoves[NOT_STATE][EQUAL_CHAR]= NOTEQUAL_STATE;

    // First, initialize all states to correspond to the BAD token type.
    // Then, reset the end states to correspond to the correct token types.
    for(int i=0; i<LAST_STATE; i++){
        mCorrespondingTokenTypes[i]=BAD_TOKEN;
    }
    mCorrespondingTokenTypes[IDENTIFIER_STATE] = IDENTIFIER_TOKEN;
    mCorrespondingTokenTypes[INTEGER_STATE] = INTEGER_TOKEN;
    mCorrespondingTokenTypes[PLUS_STATE] = PLUS_TOKEN;
    mCorrespondingTokenTypes[MINUS_STATE] = MINUS_TOKEN;
    mCorrespondingTokenTypes[SEMICOLON_STATE] = SEMICOLON_TOKEN;
    mCorrespondingTokenTypes[INSERTION_STATE] = INSERTION_TOKEN;
    mCorrespondingTokenTypes[DIVIDE_STATE] = DIVIDE_TOKEN;
    mCorrespondingTokenTypes[LPAREN_STATE] = LPAREN_TOKEN;
    mCorrespondingTokenTypes[RPAREN_STATE] = RPAREN_TOKEN;
    mCorrespondingTokenTypes[LCURLY_STATE] = LCURLY_TOKEN;
    mCorrespondingTokenTypes[RCURLY_STATE] = RCURLY_TOKEN;
    mCorrespondingTokenTypes[EOF_STATE] = ENDFILE_TOKEN;
    mCorrespondingTokenTypes[LESS_STATE] = LESS_TOKEN;
    mCorrespondingTokenTypes[GREATER_STATE] = GREATER_TOKEN;
    mCorrespondingTokenTypes[GREATEREQUAL_STATE] = GREATEREQUAL_TOKEN;
    mCorrespondingTokenTypes[EQUAL_STATE] = EQUAL_TOKEN;
    mCorrespondingTokenTypes[NOTEQUAL_STATE] = NOTEQUAL_TOKEN; 
};

MachineState StateMachineClass::UpdateState(char currentCharacter, TokenType &correspondingTokenType){
    CharacterType chartype = BAD_CHAR;
    if(currentCharacter == '+'){
        chartype == PLUS_CHAR;
    }
    if(currentCharacter == ';'){
        chartype = SEMICOLON_CHAR; 
    }
    if(currentCharacter == '<'){
        chartype = LESS_CHAR;
    }
    if(currentCharacter == '>'){
        chartype = GREATER_CHAR; 
    }
    if(currentCharacter == '/'){
        chartype = DIVIDE_CHAR;
    }
    if(currentCharacter == '('){
        chartype = LPAREN_CHAR;;
    }
    if(currentCharacter == ')'){
        chartype = RPAREN_CHAR;;
    }
    if(currentCharacter == '{'){
        chartype = LCURLY_CHAR;;
    }
    if(currentCharacter == '}'){
        chartype = RCURLY_CHAR;
    }
    if(currentCharacter == '\n'){
        chartype = NEWL_CHAR;
    }
    if(isdigit(currentCharacter)){
        chartype = DIGIT_CHAR;
    }
    if(isalpha(currentCharacter)){
        chartype = LETTER_CHAR;
    }
    if(isspace(currentCharacter)){
        chartype = WHITESPACE_CHAR;
    }
    if(currentCharacter == EOF){
        chartype = EOF_CHAR; 
    }

    correspondingTokenType = mCorrespondingTokenTypes[mCurrentState];
    mCurrentState = mLegalMoves[mCurrentState][chartype];
    return mCurrentState;
}