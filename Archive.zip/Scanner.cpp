#include "Scanner.h"
#include "Token.h"
#include <iostream>
#include <fstream>
#include <string>
using namespace std;

ScannerClass::ScannerClass(const std::string& inputFileName){
    mFin.open(inputFileName.c_str(), std::ios::binary);
    if (mFin.is_open()){
        cout << "File successfully open";
    } else{
        printf ("Error opening file");
        exit (EXIT_FAILURE);
    }
}
ScannerClass::~ScannerClass(){
    mFin.close();
}

TokenClass ScannerClass::GetNextToken(){
    MachineState currentState;
    StateMachineClass stateMachine;
    TokenType correspondingTokenType;
    char c;
    string lexeme;
    do{
        c = mFin.get();
        lexeme += c;
        currentState = stateMachine.UpdateState(c, correspondingTokenType);
        if (currentState == START_STATE){
            lexeme = "";
        };
    
    }while (currentState != CANTMOVE_STATE);
        mFin.unget();
        lexeme.pop_back();

        // if(c=='\n'){
        //     mLineNumber -= 1;
        // }

    if(correspondingTokenType == BAD_TOKEN){
        printf("Bad token type on GetNextToken()");
        exit(EXIT_FAILURE);
    }

    TokenClass tc (correspondingTokenType, lexeme);
    tc.CheckReserved();
    return tc;
}

// scanner::GetNextToken(){
//     MachineState currentState;
//     TokenType correspondingTokenType;
//     char c;
//     string lexeme;
//     StateMacineClass machine;
//     do{
//         c = mFin.getc();
//         lexeme += c;
//         currentState = machine.UpdateState(c, correspondingTokenType);
//          if (currentState == startState){
//              lexeme = ""
//          }
//     }while (currentState != CANTMOVE_STATE){
//          mFin.unget(c);
//          lexeme.pop();
//      }

//     TokenClass tc(correspondingTokenType, lexeme);
//     return tc;
// }

// MORE DETAILS NEEDED ABOVE