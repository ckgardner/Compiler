#include "Token.h"
#include <iostream>
#include <string>
#include "Scanner.h"

int main(){
    ScannerClass scanner(const std::string inputFile);
    TokenType token;
    while (token != ENDFILE_TOKEN){
        token = scanner.GetNextToken(); 
    }

    // TokenType tt = VOID_TOKEN;
    // std::string lexeme = "void";
    // TokenClass tok1(tt, lexeme);
    // std::cout << tok1 << std::endl;
}