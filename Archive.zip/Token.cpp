#include "Token.h"
#include <iostream>
#include <iomanip>

TokenClass::TokenClass(TokenType type, const std::string & lexeme){
    std::cout << "TokenClass was constructed" << std::endl;
    mType = type;
    mLexeme = lexeme;
}

void TokenClass::CheckReserved(){
    
}

std::ostream & operator<<(std::ostream & out, const TokenClass & tc){
    out.setf(std::ios::left);
    out << "Type: " << std::setw(15) << tc.GetTokenTypeName() <<
            "Lexeme: " << std::setw(15) << tc.GetLexeme();
    return out;
}